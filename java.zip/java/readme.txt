to run use cmd

use any java compiler (or use online java compiler)