to run use cmd

python3 <filename> (or use python <filename> )