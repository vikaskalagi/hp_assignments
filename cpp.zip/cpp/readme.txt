to run cmd

g++ <filename> -lpthread
./a.out

