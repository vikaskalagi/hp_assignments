to run the code

gcc <filename> -openmp
./a.out