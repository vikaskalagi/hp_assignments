to run the code
nvcc <filename>
./a.out